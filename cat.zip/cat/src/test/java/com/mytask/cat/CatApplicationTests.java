package com.mytask.cat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatApplicationTests {

	@Test
	void contextLoads() {
	}

}
