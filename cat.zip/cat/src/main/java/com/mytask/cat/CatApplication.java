package com.mytask.cat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

 

@SpringBootApplication
public class CatApplication {

 

    public static void main(String[] args) {
        SpringApplication.run(CatApplication.class, args);
    }

 

}


