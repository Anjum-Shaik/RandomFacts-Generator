package com.mytask.cat.service;

import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.mytask.cat.entities.facts;

@Service

public class FactServiceImpl implements FactService {
	
		public List<facts> getAllFacts1() {
		List<facts> list = new ArrayList<>();	
		list.add(new facts( "The first cat in space was a French cat named Felicette (a.k.a. “Astrocat”) In 1963, France blasted the cat into outer space. Electrodes implanted in her brains sent neurological signals back to Earth. She survived the trip.",
			     224));
		list.add(new facts( "Cats' hearing stops at 65 khz (kilohertz); humans' hearing stops at 20 khz.",
			     75));
		list.add(new facts( "In 1987 cats overtook dogs as the number one pet in America.",
			    60));
		list.add(new facts("Cats are the world's most popular pets, outnumbering dogs by as many as three to one",
			     84));
		list.add(new facts("On average, a cat will step for 16 hours a day", 48));
		// TODO Auto-generated method stub
		return list;
	}

		@Override
		public String getAllFacts() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public List<facts> getFAllacts() {
			// TODO Auto-generated method stub
			return null;
		}

	
		


}
