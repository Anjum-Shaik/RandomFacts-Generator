package com.mytask.cat.service;

import java.util.List;

import com.mytask.cat.entities.facts;

public interface FactService {
	


	public String getAllFacts();

	

	List<facts> getFAllacts();



	public List<facts> getAllFacts1();
	

}
