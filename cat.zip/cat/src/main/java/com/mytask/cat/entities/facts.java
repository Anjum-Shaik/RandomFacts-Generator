package com.mytask.cat.entities;

public class facts {
	String fact;
	int length;
	
	
	public facts(String fact, int length) {
		super();
		this.fact = fact;
		this.length = length;
	}


	public facts() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getFact() {
		return fact;
	}


	public void setFact(String fact) {
		this.fact = fact;
	}


	public int getLength() {
		return length;
	}


	public void setLength(int length) {
		this.length = length;
	}


	

	
	
	
}
